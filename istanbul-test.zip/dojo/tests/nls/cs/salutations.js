define(
//begin v1.x content
{
 cs: "česky",
 hello: "Ahoj"
}
//end v1.x content
);
