define(
//begin v1.x content
{
 pl: "Polski",
 hello: "Dzièn dobry"
}
//end v1.x content
);
