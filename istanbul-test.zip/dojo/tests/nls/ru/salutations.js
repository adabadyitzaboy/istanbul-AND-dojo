define(
//begin v1.x content
{
 ru: "русский",
 hello: "Привет"
}
//end v1.x content
);
