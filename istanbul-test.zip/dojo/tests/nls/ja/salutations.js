define(
//begin v1.x content
{
 ja: "\u65E5\u672C\u8A9E",
 hello: "こにちは"
}
//end v1.x content
);
