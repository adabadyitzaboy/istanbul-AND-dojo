define([
	"../main",
	"./data/utils",
	"./data/ItemFileReadStore",
	"./data/ItemFileWriteStore",
	"./data/ObjectStore"], function(dojo){
		dojo.config.usePlainJson = true;
});


