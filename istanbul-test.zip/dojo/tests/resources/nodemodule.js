/*
 * Test module for dojo/node plugin
 */

var nodemodule = module.exports = exports;

nodemodule.test = "value";