/*
 * Tests that the node.js standard require works fine
 */

module.exports = require('./nodemodule');
