/*
 * Test module for dojo/node plugin
 */

var m = module.exports = exports;

m.test = "value";