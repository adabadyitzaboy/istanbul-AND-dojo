define([], function(){
	
	return function(value){
		value++;
		return value;
	};

});
