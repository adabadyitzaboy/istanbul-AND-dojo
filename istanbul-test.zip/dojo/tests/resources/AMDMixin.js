define(["dojo/_base/declare"], function(declare){

	return declare(null, {
		amdMixinDone: true,
		constructor: function(args, node){
			this.params = args;
		}
	});

});