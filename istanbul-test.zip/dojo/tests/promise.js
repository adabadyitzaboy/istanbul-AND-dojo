define([
	"dojo/tests/Deferred",
	"dojo/tests/promise/Promise",
	"dojo/tests/when",
	"dojo/tests/promise/all",
	"dojo/tests/promise/first",
	"dojo/tests/promise/tracer"
], 1);
