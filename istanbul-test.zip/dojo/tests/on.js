define([
	"dojo/tests/on/on"
], 1);
