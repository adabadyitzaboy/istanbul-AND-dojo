define(
//begin v1.x content
{
	"nan": "非數值"
}
//end v1.x content
);