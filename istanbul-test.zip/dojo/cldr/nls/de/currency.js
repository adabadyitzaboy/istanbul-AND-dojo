define(
//begin v1.x content
{
	"AUD_displayName": "Australischer Dollar",
	"CAD_displayName": "Kanadischer Dollar",
	"CHF_displayName": "Schweizer Franken",
	"CNY_displayName": "Renminbi Yuan",
	"EUR_displayName": "Euro",
	"GBP_displayName": "Pfund Sterling",
	"HKD_displayName": "Hongkong-Dollar",
	"JPY_displayName": "Japanische Yen",
	"JPY_symbol": "¥",
	"USD_displayName": "US-Dollar",
	"USD_symbol": "$"
}
//end v1.x content
);