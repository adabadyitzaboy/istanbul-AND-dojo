define(
//begin v1.x content
{
	"AUD_displayName": "Australische dollar",
	"CAD_displayName": "Canadese dollar",
	"CHF_displayName": "Zwitserse franc",
	"CNY_displayName": "Chinese yuan renminbi",
	"EUR_displayName": "Euro",
	"GBP_displayName": "Brits pond sterling",
	"HKD_displayName": "Hongkongse dollar",
	"JPY_displayName": "Japanse yen",
	"USD_displayName": "Amerikaanse dollar"
}
//end v1.x content
);