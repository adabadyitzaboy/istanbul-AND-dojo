define(
//begin v1.x content
{
	"AUD_displayName": "avstralski dolar",
	"CAD_displayName": "kanadski dolar",
	"CHF_displayName": "švicarski frank",
	"CNY_displayName": "kitajski juan renminbi",
	"EUR_displayName": "evro",
	"GBP_displayName": "britanski funt",
	"HKD_displayName": "hongkonški dolar",
	"JPY_displayName": "japonski jen",
	"JPY_symbol": "¥",
	"USD_displayName": "ameriški dolar",
	"USD_symbol": "$"
}
//end v1.x content
);