define(
//begin v1.x content
{
	"dateFormat-full": "EEEE, d MMMM y",
	"dateFormat-short": "dd.MM.yy",
	"timeFormat-full": "HH.mm:ss 'h' zzzz"
}
//end v1.x content
);