define(
//begin v1.x content
{
	"decimal": ".",
	"group": "'",
	"currencyFormat": "¤ #,##0.00;¤-#,##0.00"
}
//end v1.x content
);