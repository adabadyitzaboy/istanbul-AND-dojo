define(
//begin v1.x content
{
	"AUD_displayName": "Ausztrál dollár",
	"CAD_displayName": "Kanadai dollár",
	"CHF_displayName": "Svájci frank",
	"CNY_displayName": "Kínai jüan renminbi",
	"EUR_displayName": "Euro",
	"GBP_displayName": "Brit font sterling",
	"HKD_displayName": "Hongkongi dollár",
	"JPY_displayName": "Japán jen",
	"JPY_symbol": "¥",
	"USD_displayName": "USA dollár",
	"USD_symbol": "$"
}
//end v1.x content
);