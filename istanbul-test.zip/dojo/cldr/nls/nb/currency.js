define(
//begin v1.x content
{
	"AUD_displayName": "australske dollar",
	"CAD_displayName": "kanadiske dollar",
	"CHF_displayName": "sveitsiske franc",
	"CNY_displayName": "kinesiske yuan renminbi",
	"EUR_displayName": "euro",
	"GBP_displayName": "britiske pund sterling",
	"HKD_displayName": "Hongkong-dollar",
	"JPY_displayName": "japanske yen",
	"USD_displayName": "amerikanske dollar"
}
//end v1.x content
);