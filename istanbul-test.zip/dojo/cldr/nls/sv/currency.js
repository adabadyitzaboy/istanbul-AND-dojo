define(
//begin v1.x content
{
	"AUD_displayName": "australisk dollar",
	"AUD_symbol": "AU$",
	"CAD_displayName": "kanadensisk dollar",
	"CHF_displayName": "schweizisk franc",
	"CNY_displayName": "kinesisk yuan renminbi",
	"EUR_displayName": "euro",
	"GBP_displayName": "brittiskt pund sterling",
	"HKD_displayName": "Hongkong-dollar",
	"JPY_displayName": "japansk yen",
	"USD_displayName": "US-dollar"
}
//end v1.x content
);