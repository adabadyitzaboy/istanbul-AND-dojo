define(
//begin v1.x content
{
	"nan": "非數值",
	"decimalFormat-short": "000兆",
	"currencyFormat": "¤#,##0.00"
}
//end v1.x content
);