define(
//begin v1.x content
{
	"AUD_displayName": "澳幣",
	"CAD_displayName": "加幣",
	"CHF_displayName": "瑞士法郎",
	"CNY_displayName": "人民幣",
	"CNY_symbol": "￥",
	"EUR_displayName": "歐元",
	"GBP_displayName": "英鎊",
	"HKD_displayName": "港幣",
	"JPY_displayName": "日圓",
	"USD_displayName": "美金",
	"USD_symbol": "$"
}
//end v1.x content
);