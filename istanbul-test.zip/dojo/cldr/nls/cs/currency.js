define(
//begin v1.x content
{
	"AUD_displayName": "australský dolar",
	"CAD_displayName": "kanadský dolar",
	"CHF_displayName": "švýcarský frank",
	"CNY_displayName": "čínský jüan",
	"EUR_displayName": "euro",
	"GBP_displayName": "britská libra",
	"HKD_displayName": "hongkongský dolar",
	"JPY_displayName": "japonský jen",
	"USD_displayName": "americký dolar"
}
//end v1.x content
);