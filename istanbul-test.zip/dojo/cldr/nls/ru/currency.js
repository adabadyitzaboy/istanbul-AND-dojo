define(
//begin v1.x content
{
	"AUD_displayName": "Австралийский доллар",
	"CAD_displayName": "Канадский доллар",
	"CHF_displayName": "Швейцарский франк",
	"CNY_displayName": "Юань Ренминби",
	"EUR_displayName": "Евро",
	"GBP_displayName": "Английский фунт стерлингов",
	"HKD_displayName": "Гонконгский доллар",
	"JPY_displayName": "Японская иена",
	"JPY_symbol": "¥",
	"USD_displayName": "Доллар США",
	"USD_symbol": "$"
}
//end v1.x content
);