define(
//begin v1.x content
{
	"AUD_displayName": "Avustralya Doları",
	"CAD_displayName": "Kanada Doları",
	"CHF_displayName": "İsviçre Frangı",
	"CNY_displayName": "Çin Yuanı",
	"EUR_displayName": "Euro",
	"GBP_displayName": "İngiliz Sterlini",
	"HKD_displayName": "Hong Kong Doları",
	"JPY_displayName": "Japon Yeni",
	"JPY_symbol": "¥",
	"USD_displayName": "ABD Doları",
	"USD_symbol": "$"
}
//end v1.x content
);