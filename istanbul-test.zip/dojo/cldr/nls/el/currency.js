define(
//begin v1.x content
{
	"AUD_displayName": "Δολάριο Αυστραλίας",
	"CAD_displayName": "Δολάριο Καναδά",
	"CHF_displayName": "Φράγκο Ελβετίας",
	"CNY_displayName": "Γιουάν Ρενμίμπι Κίνας",
	"EUR_displayName": "Ευρώ",
	"GBP_displayName": "Λίρα Στερλίνα Βρετανίας",
	"HKD_displayName": "Δολάριο Χονγκ Κονγκ",
	"JPY_displayName": "Γιεν Ιαπωνίας",
	"USD_displayName": "Δολάριο ΗΠΑ",
	"USD_symbol": "$"
}
//end v1.x content
);