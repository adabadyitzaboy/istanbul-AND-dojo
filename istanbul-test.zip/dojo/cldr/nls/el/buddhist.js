define(
//begin v1.x content
{
	"dateFormat-full": "EEEE, d MMMM, y G",
	"dateFormat-long": "d MMMM, y G",
	"dateFormat-medium": "d MMM, y G",
	"dateFormat-short": "d/M/yyyy",
	"dateFormatItem-Ed": "E d",
	"dateFormatItem-Gy": "y G",
	"dateFormatItem-Md": "d/M",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormatItem-MMM": "LLL",
	"dateFormatItem-MMMd": "d MMM",
	"dateFormatItem-MMMEd": "E, d MMM",
	"dateFormatItem-y": "y G",
	"dateFormatItem-yM": "M/y",
	"dateFormatItem-yMd": "d/M/y",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-yMMM": "LLL, y G",
	"dateFormatItem-yMMMd": "d MMM, y G",
	"dateFormatItem-yMMMEd": "E, d MMM, y G",
	"days-format-abbr": [
		"Κυρ",
		"Δευ",
		"Τρι",
		"Τετ",
		"Πεμ",
		"Παρ",
		"Σαβ"
	],
	"days-format-narrow": [
		"Κ",
		"Δ",
		"Τ",
		"Τ",
		"Π",
		"Π",
		"Σ"
	],
	"days-format-wide": [
		"Κυριακή",
		"Δευτέρα",
		"Τρίτη",
		"Τετάρτη",
		"Πέμπτη",
		"Παρασκευή",
		"Σάββατο"
	],
	"days-standAlone-abbr": [
		"Κυρ",
		"Δευ",
		"Τρί",
		"Τετ",
		"Πέμ",
		"Παρ",
		"Σάβ"
	],
	"days-standAlone-narrow": [
		"Κ",
		"Δ",
		"Τ",
		"Τ",
		"Π",
		"Π",
		"Σ"
	],
	"days-standAlone-wide": [
		"Κυριακή",
		"Δευτέρα",
		"Τρίτη",
		"Τετάρτη",
		"Πέμπτη",
		"Παρασκευή",
		"Σάββατο"
	],
	"quarters-format-abbr": [
		"Τ1",
		"Τ2",
		"Τ3",
		"Τ4"
	],
	"quarters-format-wide": [
		"1ο τρίμηνο",
		"2ο τρίμηνο",
		"3ο τρίμηνο",
		"4ο τρίμηνο"
	],
	"quarters-standAlone-abbr": [
		"Τ1",
		"Τ2",
		"Τ3",
		"Τ4"
	],
	"quarters-standAlone-wide": [
		"1ο τρίμηνο",
		"2ο τρίμηνο",
		"3ο τρίμηνο",
		"4ο τρίμηνο"
	],
	"dayPeriods-format-wide-am": "π.μ.",
	"dayPeriods-format-wide-pm": "μ.μ.",
	"dateFormatItem-yQ": "y Q",
	"dateFormatItem-yQQQ": "y QQQ",
	"timeFormat-full": "h:mm:ss a zzzz",
	"timeFormat-long": "h:mm:ss a z",
	"timeFormat-medium": "h:mm:ss a",
	"timeFormat-short": "h:mm a",
	"months-format-abbr": [
		"Ιαν",
		"Φεβ",
		"Μαρ",
		"Απρ",
		"Μαϊ",
		"Ιουν",
		"Ιουλ",
		"Αυγ",
		"Σεπ",
		"Οκτ",
		"Νοε",
		"Δεκ"
	],
	"months-format-narrow": [
		"Ι",
		"Φ",
		"Μ",
		"Α",
		"Μ",
		"Ι",
		"Ι",
		"Α",
		"Σ",
		"Ο",
		"Ν",
		"Δ"
	],
	"months-format-wide": [
		"Ιανουαρίου",
		"Φεβρουαρίου",
		"Μαρτίου",
		"Απριλίου",
		"Μαΐου",
		"Ιουνίου",
		"Ιουλίου",
		"Αυγούστου",
		"Σεπτεμβρίου",
		"Οκτωβρίου",
		"Νοεμβρίου",
		"Δεκεμβρίου"
	],
	"months-standAlone-abbr": [
		"Ιαν",
		"Φεβ",
		"Μάρ",
		"Απρ",
		"Μάι",
		"Ιούν",
		"Ιούλ",
		"Αυγ",
		"Σεπ",
		"Οκτ",
		"Νοέ",
		"Δεκ"
	],
	"months-standAlone-narrow": [
		"Ι",
		"Φ",
		"Μ",
		"Α",
		"Μ",
		"Ι",
		"Ι",
		"Α",
		"Σ",
		"Ο",
		"Ν",
		"Δ"
	],
	"months-standAlone-wide": [
		"Ιανουάριος",
		"Φεβρουάριος",
		"Μάρτιος",
		"Απρίλιος",
		"Μάιος",
		"Ιούνιος",
		"Ιούλιος",
		"Αύγουστος",
		"Σεπτέμβριος",
		"Οκτώβριος",
		"Νοέμβριος",
		"Δεκέμβριος"
	]
}
//end v1.x content
);