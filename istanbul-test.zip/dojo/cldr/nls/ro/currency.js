define(
//begin v1.x content
{
	"AUD_displayName": "dolar australian",
	"CAD_displayName": "dolar canadian",
	"CHF_displayName": "franc elvețian",
	"CNY_displayName": "yuan renminbi chinezesc",
	"EUR_displayName": "euro",
	"GBP_displayName": "liră sterlină",
	"HKD_displayName": "dolar Hong Kong",
	"JPY_displayName": "yen japonez",
	"USD_displayName": "dolar american",
	"USD_symbol": "$"
}
//end v1.x content
);