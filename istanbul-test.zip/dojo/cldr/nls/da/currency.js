define(
//begin v1.x content
{
	"AUD_displayName": "Australsk dollar",
	"CAD_displayName": "Canadisk dollar",
	"CHF_displayName": "Schweizisk franc",
	"CNY_displayName": "Kinesisk yuan renminbi",
	"EUR_displayName": "Euro",
	"GBP_displayName": "Britisk pund",
	"HKD_displayName": "Hongkong dollar",
	"JPY_displayName": "Japansk yen",
	"USD_displayName": "Amerikansk dollar",
	"USD_symbol": "$"
}
//end v1.x content
);