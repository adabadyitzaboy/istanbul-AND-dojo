define(
//begin v1.x content
{
	"AUD_displayName": "Australian dollari",
	"CAD_displayName": "Kanadan dollari",
	"CHF_displayName": "Sveitsin frangi",
	"CNY_displayName": "Kiinan yuan",
	"EUR_displayName": "euro",
	"GBP_displayName": "Englannin punta",
	"HKD_displayName": "Hongkongin dollari",
	"JPY_displayName": "Japanin jeni",
	"JPY_symbol": "¥",
	"USD_displayName": "Yhdysvaltain dollari",
	"USD_symbol": "$"
}
//end v1.x content
);