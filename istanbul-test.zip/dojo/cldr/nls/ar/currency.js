define(
//begin v1.x content
{
	"AUD_displayName": "دولار أسترالي",
	"CAD_displayName": "دولار كندي",
	"CHF_displayName": "فرنك سويسري",
	"CNY_displayName": "يوان صيني",
	"CNY_symbol": "ي.ص",
	"EUR_displayName": "يورو",
	"GBP_displayName": "جنيه إسترليني",
	"HKD_displayName": "دولار هونج كونج",
	"JPY_displayName": "ين ياباني",
	"USD_displayName": "دولار أمريكي"
}
//end v1.x content
);