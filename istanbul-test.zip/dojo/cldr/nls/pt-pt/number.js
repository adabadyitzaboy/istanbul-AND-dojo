define(
//begin v1.x content
{
	"group": " ",
	"decimalFormat-short": "000 Bi",
	"currencyFormat": "#,##0.00 ¤"
}
//end v1.x content
);